---
name: Discovery Engine
colors:
  surface: '#fff8f7'
  surface-dim: '#f1d3d5'
  surface-bright: '#fff8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0f0'
  surface-container: '#ffe9ea'
  surface-container-high: '#ffe1e3'
  surface-container-highest: '#f9dbdd'
  on-surface: '#271719'
  on-surface-variant: '#5b4042'
  inverse-surface: '#3e2c2d'
  inverse-on-surface: '#ffeced'
  outline: '#8f6f72'
  outline-variant: '#e3bdc0'
  surface-tint: '#bd0043'
  primary: '#b90041'
  on-primary: '#ffffff'
  primary-container: '#df2457'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb2ba'
  secondary: '#5a5d73'
  on-secondary: '#ffffff'
  secondary-container: '#dbdef8'
  on-secondary-container: '#5e6177'
  tertiary: '#006a34'
  on-tertiary: '#ffffff'
  tertiary-container: '#008644'
  on-tertiary-container: '#f6fff3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9dc'
  primary-fixed-dim: '#ffb2ba'
  on-primary-fixed: '#400011'
  on-primary-fixed-variant: '#910031'
  secondary-fixed: '#dee1fa'
  secondary-fixed-dim: '#c2c5de'
  on-secondary-fixed: '#161b2d'
  on-secondary-fixed-variant: '#42465a'
  tertiary-fixed: '#7dfca2'
  tertiary-fixed-dim: '#5fde88'
  on-tertiary-fixed: '#00210c'
  on-tertiary-fixed-variant: '#005227'
  background: '#fff8f7'
  on-background: '#271719'
  surface-variant: '#f9dbdd'
typography:
  wordmark:
    fontFamily: Assistant
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 100%
    letterSpacing: -0.04em
  subtitle:
    fontFamily: Assistant
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.12em
  h1:
    fontFamily: Assistant
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.01em
  h2:
    fontFamily: Assistant
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 32px
  h3:
    fontFamily: Assistant
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  body:
    fontFamily: Assistant
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-bold:
    fontFamily: Assistant
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
  button:
    fontFamily: Assistant
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.02em
  label:
    fontFamily: Assistant
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar_width: 260px
  container_padding: 32px
  card_padding: 24px
  stack_gap: 16px
  grid_gutter: 24px
---

## Brand & Style
The design system for this internal research console balances Myntra's high-energy fashion heritage with the rigor of a data-driven PM environment. The aesthetic is **Modern Corporate** with a focus on **Precision Minimalism**. By stripping away shadows and excessive decoration, the UI prioritizes evidence-first decision-making. 

The personality is professional, sharp, and authoritative. Visual hierarchy is established through high-contrast typography and intentional use of the signature primary color against a neutral, "Gallery" grey backdrop. Every element should feel engineered and deliberate.

## Colors
The palette is rooted in the iconic Myntra Pink, utilized sparingly to draw attention to primary actions and critical data points. 

- **Primary & Interactive:** Use `#FF3F6C` for actions and branding. Hover states shift to `#E3365B`.
- **Neutral Foundation:** The background uses `#F5F5F6` to create a distinct separation from white `#FFFFFF` surface cards.
- **Typography & UI:** Primary text is a deep charcoal `#282C3F` for maximum legibility. Secondary text uses `#535766` for metadata and labels.
- **Sentiment Logic:** For PM research, use a soft pink-red for frustrated user sentiment and a muted, professional green-gray for positive sentiment.

## Typography
This design system uses **Assistant** exclusively to maintain a clean, versatile, and modern sans-serif feel.

- **Headlines:** Use Extra-Bold (800) for all primary titles to create an authoritative, editorial look.
- **Body Text:** Standard body text is 14px Regular (400) for optimal density in data-heavy views.
- **System Labels:** Use 12px Semi-Bold (600) in the secondary text color for form labels and metadata.
- **Brand Identity:** The Myntra wordmark must be rendered in 800 weight with tight tracking, while the 'DISCOVERY ENGINE' subtitle uses wide tracking (0.12em) and uppercase styling to denote its specialized function.

## Layout & Spacing
The layout follows a rigid, structured approach to support complex data visualization and research analysis.

- **Sidebar:** A fixed white sidebar (`#FFFFFF`) on the left, 260px wide, separated by a 1px solid border (`#EAEAEC`).
- **Main Canvas:** A grey background (`#F5F5F6`) that contains white surface cards.
- **Grid:** Use a 12-column grid for the main content area with 24px gutters.
- **Rhythm:** Spacing follows 8px increments (8, 16, 24, 32, 48, 64) to maintain mathematical consistency across the console.

## Elevation & Depth
This design system employs a **Flat UI** philosophy. 
- **No Shadows:** Do not use drop shadows or ambient blurs for elevation. 
- **Z-Axis:** Depth is communicated through color contrast and borders only. 
- **Surfaces:** Use `#FFFFFF` cards against the `#F5F5F6` background to indicate interactable or grouped content.
- **Dividers:** Use 1px solid `#EAEAEC` for all separators, table borders, and container outlines.

## Shapes
The shape language is sharp and professional, reflecting a high-precision tool.
- **Cards & Containers:** Use a consistent 4px corner radius.
- **Interactive Elements:** Buttons and form inputs use a tighter 2px corner radius for a "technical" appearance.
- **Chips:** Sentiment chips and status tags should use a 2px radius or be fully squared if preferred for a more brutalist edge, though 2px is the default.

## Components
- **Buttons:** Primary buttons are solid `#FF3F6C` with white text, 700 weight, and 2px radius. Secondary buttons use a `#EAEAEC` border and `#282C3F` text.
- **Cards:** White background, 4px radius, 1px border. No shadow. Internal padding should be a generous 24px.
- **Sentiment Chips:** 
  - *Frustrated:* Background `#FEE8ED`, Text `#FF3F6C`, 2px radius.
  - *Positive:* Background `#E8F2EE`, Text `#43665E`, 2px radius.
- **Data Tables:** Headers in `#F5F5F6` with 700 weight text. Rows separated by 1px `#EAEAEC` lines. No alternating row colors; use hover highlights in `#F5F5F6` instead.
- **Charts:** Use a 2-color primary scheme. Primary data series in `#FF3F6C`, secondary or baseline data in `#282C3F`. Use `#535766` for axes and grid lines.
- **Input Fields:** 1px `#EAEAEC` border, 2px radius. On focus, the border changes to `#282C3F` (not pink) to maintain a neutral research environment.